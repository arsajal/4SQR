<table border="0" width="100%" cellpadding=10 cellspacing=0 bgcolor='#B6292F'>
<tr>
	<td align=left width=50><a href="home.php"><img src="../images/cropped-logo-2-1-32x32.jpg" border=0></a></td>
	<td class=cat2>
		<img src="arrow_2.png" border=0> <a href="home_pg_slider.php"<?php if($menu=='homepg') { echo " class=menuSelected"; }?>>Home Pg Slider</a>
		&nbsp;&nbsp;&nbsp;
		<img src="arrow_2.png" border=0> <a href="works_pg.php"<?php if($menu=='workspg') { echo " class=menuSelected"; }?>>Works Pg</a>
		&nbsp;&nbsp;&nbsp;
		<img src="arrow_2.png" border=0> <a href="clients_work.php"<?php if($menu=='clientswork') { echo " class=menuSelected"; }?>>Clients Work</a>
	</td>
	<td class=cat2 align=right><img src="arrow_2.png" border=0> <a href="signout.php">Sign Out</a></td>
</tr>
</table>
