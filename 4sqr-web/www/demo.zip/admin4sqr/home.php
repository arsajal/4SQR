<?php session_start();
require("session.php");
?>

<html>
<head>
<meta http-equiv="refresh" content="300">
<?php require_once('head.php'); ?>
</head>

<body topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0" marginwidth="0" marginheight="0" bgcolor='#FFFFFF' background="../images/bg.png" style=" background-attachment: fixed;">
<?php
require_once('menu.php');
?>
</body>

</html>
