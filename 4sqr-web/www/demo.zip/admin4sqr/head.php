<meta charset="utf-8">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport'>
<meta name="viewport" content="width=device-width">
<title>ADMIN</title>
<link type="image/png" rel="icon" href="../images/logo-2.png">
<link type="image/png" rel="shortcut icon" href="../images/logo-2.png">
<link href="style.css" rel="stylesheet" type="text/css">
