<?php
date_default_timezone_set('Asia/Dhaka');
$ts = time();
$today = date('Y-m-d', $ts);
$now = date('Y-m-d H:i:s', $ts);
