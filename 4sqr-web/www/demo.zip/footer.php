<footer class="footer-wrp">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="footer-inr">
					<div class="ftr-socials">
						<ul class="reset-list">
						<li><a target="_blank" href="https://www.facebook.com/prantography"><i class="fab fa-facebook-f"></i></a></li>
						<li><a target="_blank" href="https://www.instagram.com/prantography"><i class="fab fa-instagram"></i></a></li>
						<li><a href="mailto:prantography@gmail.com"><i class="fa-solid fa-envelope"></i></a></li>
						<li><a href="tel:+8801798613561"><i class="fa-solid fa-phone"></i></a></li>
						</ul>
					</div>
					<div class="ftr-copyright">
						<p><p>© Copyright 2025 &nbsp; <b>FOURSQUARE</b> &nbsp; All rights reserved.</p></p>
					</div>
					<div class="develop-by">
						<p>Re-Developed by <a target="_blank" href="https://ideaintec.com/"> Amin.Mehedi</a></p>
					</div>
				</div>
			</div>
		</div>
	</div> 
</footer>